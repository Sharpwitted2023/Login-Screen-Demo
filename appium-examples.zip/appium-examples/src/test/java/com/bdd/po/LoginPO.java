package com.bdd.po;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.bdd.resusable.ReusableComponent;



public class LoginPO extends ReusableComponent  {
	
	ReusableComponent rc=new ReusableComponent();
	
	 static By userName=By.xpath("(//*[@id='user-name'])");
	 static By userPassword=By.xpath("(//*[@id='password'])");
	 By clicklogin=By.xpath("//*[@class='ico-login']");
	 WebDriver driver;
	 String testStepsName="credentials";
		
	
	public void enterCredentials(String uName,String password)throws Throwable {
		// TODO Auto-generated method stub
		if(rc.isElementPresent(userName)){
			
			
			rc.sendChars(userName, uName);
			System.out.println("taking screenshot");
			rc.CaptureScreenShotWithTestStepName();
			System.out.println("success screenshot");
			
		}else{
			System.out.println("failed");
		}
		
		if(rc.isElementPresent(userPassword)){
			
			rc.sendChars(userPassword, password);
			
			
		}else{
			System.out.println("failed");
		}
	}


	public void clickLogin()throws Throwable {
		// TODO Auto-generated method stub
			if(rc.isElementPresent(clicklogin)){
			
			rc.mouseHover(clicklogin);
			
			rc.clickElement(clicklogin);
			Thread.sleep(5000);
			
		}else{
			System.out.println("failed");
		}
	}
	 


}
