package com.realdevice.image_injection;

import io.appium.java_client.MobileBy;
import io.appium.java_client.android.AndroidDriver;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.rules.TestWatcher;
import org.junit.runner.Description;
import org.openqa.selenium.By;
import org.openqa.selenium.MutableCapabilities;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import java.io.IOException;
import java.net.URL;

import static helpers.Constants.region;
import static org.assertj.core.api.Assertions.assertThat;
import static org.testng.Assert.assertEquals;

public class ImageInjectionAndroidTest {

    @Rule
    public TestName name = new TestName();

    By appLogo=By.xpath("//android.view.View[@content-desc=\"One Healthcare ID\"]/android.widget.Image");
    By loginpageTtitle=By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.webkit.WebView/android.webkit.WebView/android.view.View[1]/android.view.View[3]/android.widget.TextView[1]");
    By usernameID=By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.webkit.WebView/android.webkit.WebView/android.view.View[1]/android.view.View[3]/android.view.View[1]/android.view.View[2]/android.view.View/android.widget.EditText");
    By passwordID=By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.webkit.WebView/android.webkit.WebView/android.view.View[1]/android.view.View[3]/android.view.View[1]/android.view.View[4]/android.view.View/android.widget.EditText");
    By submitButtonID=By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.webkit.WebView/android.webkit.WebView/android.view.View[1]/android.view.View[3]/android.view.View[1]/android.widget.Button");
    
    
//    String usernameID = "userNameId_input";
//    String passwordID = "passwdId_input";
//    String submitButtonID = "SignIn";
    
    By signInAccesscode=By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[3]/android.view.View[1]/android.view.View[1]/android.view.View[3]/android.view.View/android.view.View/android.widget.EditText");
    By skipCheckbox=By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[3]/android.view.View[1]/android.view.View[1]/android.view.View[6]/android.widget.CheckBox\n");
    By clickNextbutton=By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[3]/android.view.View[1]/android.view.View[2]/android.widget.Button");
    
    By clickOnSchedule=By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.ViewGroup/android.support.v4.widget.DrawerLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[3]/android.view.ViewGroup[1]/android.widget.Button");
    By verifyScheduleHeader=By.xpath("stg.com.optum.droid:id/toolbar_title");
    
    By clickOnleftArrow=By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.ViewGroup/android.support.v4.widget.DrawerLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[1]/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup[1]/android.widget.ImageView");
    By appointmentsHeader=By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.ViewGroup/android.support.v4.widget.DrawerLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup[1]/android.view.ViewGroup/android.widget.ListView/android.widget.LinearLayout[1]/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.widget.TextView");
    By verifyName=By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.ViewGroup/android.support.v4.widget.DrawerLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup[1]/android.view.ViewGroup/android.widget.ListView/android.widget.LinearLayout[2]/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup[1]/android.widget.TextView");
    By clickondots=By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.ViewGroup/android.support.v4.widget.DrawerLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup[1]/android.view.ViewGroup/android.widget.ListView/android.widget.LinearLayout[2]/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[4]/android.view.ViewGroup/android.view.ViewGroup/android.widget.ImageView");
    By verifyAutoCall=By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.ViewGroup/android.support.v4.widget.DrawerLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup[1]/android.view.ViewGroup/android.widget.ListView/android.widget.LinearLayout[2]/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[6]/android.view.ViewGroup[2]/android.view.ViewGroup[2]/android.widget.TextView");
    By verifyMapRoute=By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.ViewGroup/android.support.v4.widget.DrawerLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup[1]/android.view.ViewGroup/android.widget.ListView/android.widget.LinearLayout[2]/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[6]/android.view.ViewGroup[4]/android.view.ViewGroup[2]/android.widget.TextView");
    By verifyCallTeamCare=By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.ViewGroup/android.support.v4.widget.DrawerLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup[1]/android.view.ViewGroup/android.widget.ListView/android.widget.LinearLayout[2]/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[6]/android.view.ViewGroup[6]/android.view.ViewGroup[2]/android.widget.TextView");
    By AddNewTask=By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.ViewGroup/android.support.v4.widget.DrawerLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup[1]/android.view.ViewGroup/android.widget.ListView/android.widget.LinearLayout[2]/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[6]/android.view.ViewGroup[8]/android.view.ViewGroup[2]/android.widget.TextView");

    By clickbackToMenu=By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.ViewGroup/android.support.v4.widget.DrawerLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[1]/android.widget.ImageButton");
    
    By ProductTitle = By.xpath("//android.widget.TextView[@text='PRODUCTS']");
    By testMenu = By.xpath("//android.view.ViewGroup[@content-desc='test-Menu']");
    By testMenuItemQRCode = By.xpath("//android.view.ViewGroup[@content-desc='test-QR CODE SCANNER']");
    By testMenuItemWebView = By.xpath("//android.view.ViewGroup[@content-desc='test-WEBVIEW']");

    protected AndroidDriver driver;


    @Before
    public void setup() throws IOException {

        System.out.println("Sauce - BeforeEach hook");

        String username = "oauth-saucebecs-cb98f";
        String accesskey = "6fd67318-2ee5-4cfc-bd48-d2dbdca8f768";
        

        String sauceUrl;
        if (region.equalsIgnoreCase("eu")) {
            sauceUrl = "@ondemand.eu-central-1.saucelabs.com:443";
        } else {
            sauceUrl = "@ondemand.us-west-1.saucelabs.com:443";
        }
        String SAUCE_REMOTE_URL = "https://" + username + ":" + accesskey + sauceUrl +"/wd/hub";
        System.out.println(SAUCE_REMOTE_URL);
        URL url = new URL(SAUCE_REMOTE_URL);

        MutableCapabilities caps = new MutableCapabilities();
        caps.setCapability("platformName", "Android");
        caps.setCapability("appium:platformVersion", "10");
        caps.setCapability("appium:deviceName", "Samsung Galaxy S9");
        //caps.setCapability("appium:orientation", "portrait");
        caps.setCapability("appium:app", "storage:filename=ProvidersApp_1.11.0.2_STG_64.apk");
        MutableCapabilities sauceOptions = new MutableCapabilities();
        sauceOptions.setCapability("username", username);
        sauceOptions.setCapability("accessKey", accesskey);
        caps.setCapability("sauce:options", sauceOptions);
        // Launch remote browser and set it as the current thread
        driver = new AndroidDriver(url, caps);
        
        System.out.println("Application Started.......");
    }

    @Test
    public void imageInjectionScanQRcode() throws Throwable {
        System.out.println("Sauce - start test imageInjection_scan_QR_code");
        
        //validate app logo
        appLogo();
        
        //Validate Title of the App
        validateTitle();
        
        // Login
        login("shirema5", "Sharp@901");
        
        //OTP
        validateOTP();

       
        try
        {
            Thread.sleep(5000);
        }
        catch(InterruptedException ex)
        {
            Thread.currentThread().interrupt();
        }

    }

    @Rule
    public TestWatcher watchman= new TestWatcher() {
        @Override
        protected void failed(Throwable e, Description description) {
            try {
                System.out.println("Test Failed!");
                driver.executeScript("sauce:job-result=failed");
            } catch (Exception ignored) {
            } finally {
                driver.quit();
            }
        }

        @Override
        protected void succeeded(Description description) {
            try {
                System.out.println("Test Passed!");
                driver.executeScript("sauce:job-result=passed");
            } catch (Exception ignored) {
            } finally {
                driver.quit();
            }
        }
    };
    
    private void appLogo() {
        
        	WebDriverWait wait = new WebDriverWait(driver, 30);

            WebElement appTitle = wait.until(ExpectedConditions.visibilityOfElementLocated(appLogo));
            String getTitle=appTitle.getText();
       //     assertEquals("One Healthcare ID",getTitle);
            
            System.out.println("Title Validate: "+getTitle);
           
       
    }
    
   

	private void validateTitle() {
        
    	WebDriverWait wait = new WebDriverWait(driver, 60);

        WebElement signinTitle = wait.until(ExpectedConditions.visibilityOfElementLocated(loginpageTtitle));
        String getTitle=signinTitle.getText();
      //  assertEquals("Sign In With Your One Healthcare ID",getTitle);
        System.out.println("Sign In header Validate: "+getTitle);
       
   }
    
    private void login(String user, String pass) {
        try {
            driver.context("NATIVE_APP");

            WebDriverWait wait = new WebDriverWait(driver, 60);
            final WebElement usernameEdit = wait.until(ExpectedConditions.visibilityOfElementLocated(usernameID));

            usernameEdit.click();
            usernameEdit.sendKeys(user);
            
            System.out.println("Entered Username :"+user);

            WebDriverWait wait2 = new WebDriverWait(driver, 60);
            final WebElement passwordEdit = wait2.until(ExpectedConditions.visibilityOfElementLocated(passwordID));

            //WebElement passwordEdit = (WebElement) driver.findElementById(passwordID);
            passwordEdit.click();
            passwordEdit.sendKeys(pass);
            
            System.out.println("Entered Password :"+pass);
            
            driver.hideKeyboard();

            WebDriverWait wait3 = new WebDriverWait(driver, 60);
            final WebElement submitButton = wait3.until(ExpectedConditions.visibilityOfElementLocated(submitButtonID));

           // WebElement submitButton = (WebElement) driver.findElementByAccessibilityId(submitButtonID);
            submitButton.click();
            
           
            
            System.out.println("Login Successfull");
            
            Thread.sleep(3000);

        } catch (Exception e) {
            System.out.println("*** Problem to login: " + e.getMessage());
        }
    }
    
    private void validateOTP() throws Throwable {
        
    	WebDriverWait wait = new WebDriverWait(driver, 90);
    	Thread.sleep(30000);
        WebElement enterOTP = wait.until(ExpectedConditions.visibilityOfElementLocated(signInAccesscode));
        enterOTP.click();
        System.out.println("Enter access code...");
        Thread.sleep(30000);
        
        enterOTP.sendKeys("");
        System.out.println("OTP entered Successfully");
        
        WebElement Checkbox = wait.until(ExpectedConditions.visibilityOfElementLocated(skipCheckbox));
        Checkbox.click();
        System.out.println("Skip checkbox selected");
        
        WebElement clkNextbutton = wait.until(ExpectedConditions.visibilityOfElementLocated(clickNextbutton));
        clkNextbutton.click();
        System.out.println("Next button clicked");
   }
    
    private void scheduleScreen()throws Throwable{
    	
    	WebDriverWait wait = new WebDriverWait(driver, 90);
    	Thread.sleep(30000);
        WebElement clkSchedule = wait.until(ExpectedConditions.visibilityOfElementLocated(clickOnSchedule));
        clkSchedule.click();
        
        WebDriverWait wait2 = new WebDriverWait(driver, 90);
    	Thread.sleep(30000);
        WebElement verScheduleHeader = wait2.until(ExpectedConditions.visibilityOfElementLocated(verifyScheduleHeader));
        verScheduleHeader.click();
        
        WebDriverWait wait3 = new WebDriverWait(driver, 90);
    	Thread.sleep(30000);
        WebElement clkOnLeftArrow = wait3.until(ExpectedConditions.visibilityOfElementLocated(clickOnleftArrow));
        clkOnLeftArrow.click();
        
        WebDriverWait wait4 = new WebDriverWait(driver, 90);
    	Thread.sleep(30000);
        WebElement valappointmentHeader = wait4.until(ExpectedConditions.visibilityOfElementLocated(appointmentsHeader));
        valappointmentHeader.click();
        
        WebDriverWait wait5 = new WebDriverWait(driver, 90);
    	Thread.sleep(30000);
        WebElement verName = wait5.until(ExpectedConditions.visibilityOfElementLocated(verifyName));
        verName.click();
        
        WebDriverWait wait6 = new WebDriverWait(driver, 90);
    	Thread.sleep(30000);
        WebElement clkSchDots = wait6.until(ExpectedConditions.visibilityOfElementLocated(clickondots));
        clkSchDots.click();
        
        WebDriverWait wait7 = new WebDriverWait(driver, 90);
    	Thread.sleep(30000);
        WebElement verAutoCal = wait7.until(ExpectedConditions.visibilityOfElementLocated(verifyAutoCall));
        verAutoCal.click();
        
        WebDriverWait wait8 = new WebDriverWait(driver, 90);
    	Thread.sleep(30000);
        WebElement verMapRoute = wait8.until(ExpectedConditions.visibilityOfElementLocated(verifyMapRoute));
        verMapRoute.click();
        
        WebDriverWait wait9 = new WebDriverWait(driver, 90);
    	Thread.sleep(30000);
        WebElement verCallTeamCare = wait9.until(ExpectedConditions.visibilityOfElementLocated(verifyCallTeamCare));
        verCallTeamCare.click();
        
        WebDriverWait wait10 = new WebDriverWait(driver, 90);
    	Thread.sleep(30000);
        WebElement verAddNewTask = wait10.until(ExpectedConditions.visibilityOfElementLocated(AddNewTask));
        verAddNewTask.click();
        
        WebDriverWait wait11 = new WebDriverWait(driver, 90);
    	Thread.sleep(30000);
        WebElement clkbackToMenu = wait11.until(ExpectedConditions.visibilityOfElementLocated(clickbackToMenu));
        clkbackToMenu.click();
        
        
    }
    
    private void addTasks()throws Throwable{
    	WebDriverWait wait11 = new WebDriverWait(driver, 90);
    	Thread.sleep(30000);
        WebElement clkbackToMenu = wait11.until(ExpectedConditions.visibilityOfElementLocated(clickbackToMenu));
        
    }

    private boolean isOnProductsPage() {

        //Create an instance of a Selenium explicit wait so that we can dynamically wait for an element
        WebDriverWait wait = new WebDriverWait(driver, 5);

        //wait for the product field to be visible and store that element into a variable
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(ProductTitle));
        } catch (TimeoutException e){
            return false;
        }
        return true;
    }

    private void clickMenu() {
        driver.findElement(testMenu).click();
    }
    private void selecMenuQRCodeScanner() {
        WebDriverWait wait = new WebDriverWait(driver, 5);

        WebElement QCCodeMenu = wait.until(ExpectedConditions.visibilityOfElementLocated(testMenuItemQRCode));
        QCCodeMenu.click();
    }
}