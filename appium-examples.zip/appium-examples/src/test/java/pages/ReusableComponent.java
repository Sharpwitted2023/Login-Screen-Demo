package pages;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import io.appium.java_client.android.AndroidDriver;

public class ReusableComponent {
	OptumProviderPO op=new OptumProviderPO();
	
	public AndroidDriver<WebElement> driver;

	
	 public void appLogo() {
       	 WebDriverWait wait = new WebDriverWait(driver, 30);
         WebElement appTitle = wait.until(ExpectedConditions.visibilityOfElementLocated(op.appLogo));
         String getTitle=appTitle.getText();
         
         System.out.println("Title Validate: "+getTitle);
        }
	 
	 public void validateTitle() {
	        
	    	WebDriverWait wait = new WebDriverWait(driver, 60);

	        WebElement signinTitle = wait.until(ExpectedConditions.visibilityOfElementLocated(op.loginpageTtitle));
	        String getTitle=signinTitle.getText();
	      //  assertEquals("Sign In With Your One Healthcare ID",getTitle);
	        System.out.println("Sign In header Validate: "+getTitle);
	       
	   }
	    
	    public void login(String userName, String passWord) {
	        try {
	            driver.context("NATIVE_APP");

	            WebDriverWait wait0 = new WebDriverWait(driver, 60);
	            final WebElement usernameHeader = wait0.until(ExpectedConditions.visibilityOfElementLocated(op.usernameIDHeader));
	            String uNameHeader=usernameHeader.getText();
	            Assert.assertEquals("One Healthcare ID or email address",uNameHeader);
	            
	            
	            
	            WebDriverWait wait = new WebDriverWait(driver, 60);
	            final WebElement usernameEdit = wait.until(ExpectedConditions.visibilityOfElementLocated(op.usernameID));

	            usernameEdit.click();
	            usernameEdit.sendKeys(userName);
	            
	            System.out.println("Entered Username :"+userName);
	            
	            WebDriverWait wait02 = new WebDriverWait(driver, 60);
	            final WebElement passwordHeader = wait02.until(ExpectedConditions.visibilityOfElementLocated(op.passwordIDHeader));
	            String pwdHeader=passwordHeader.getText();
	            Assert.assertEquals("Password",pwdHeader);
	            

	            WebDriverWait wait2 = new WebDriverWait(driver, 60);
	            final WebElement passwordEdit = wait2.until(ExpectedConditions.visibilityOfElementLocated(op.passwordID));

	            //WebElement passwordEdit = (WebElement) driver.findElementById(passwordID);
	            passwordEdit.click();
	            passwordEdit.sendKeys(passWord);
	            
	            System.out.println("Entered Password :"+passWord);
	            
	            driver.hideKeyboard();

	            WebDriverWait wait3 = new WebDriverWait(driver, 60);
	            final WebElement submitButton = wait3.until(ExpectedConditions.visibilityOfElementLocated(op.submitButtonID));

	           // WebElement submitButton = (WebElement) driver.findElementByAccessibilityId(submitButtonID);
	            submitButton.click();
	            
	           
	            
	            System.out.println("Login Successfull");
	            
	            Thread.sleep(3000);

	        } catch (Exception e) {
	            System.out.println("*** Problem to login: " + e.getMessage());
	        }
	    }
	    
	    public void invalidlogin(String userName, String invalid_pwd) {
	        try {
	            driver.context("NATIVE_APP");

	            WebDriverWait wait = new WebDriverWait(driver, 60);
	            final WebElement usernameEdit = wait.until(ExpectedConditions.visibilityOfElementLocated(op.usernameID));

	            usernameEdit.click();
	            usernameEdit.sendKeys(userName);
	            
	            System.out.println("Entered Username :"+userName);

	            WebDriverWait wait2 = new WebDriverWait(driver, 60);
	            final WebElement passwordEdit = wait2.until(ExpectedConditions.visibilityOfElementLocated(op.passwordID));

	            //WebElement passwordEdit = (WebElement) driver.findElementById(passwordID);
	            passwordEdit.click();
	            passwordEdit.sendKeys(invalid_pwd);
	            
	            System.out.println("Entered Password :"+invalid_pwd);
	            
	            driver.hideKeyboard();

	            WebDriverWait wait3 = new WebDriverWait(driver, 60);
	            final WebElement submitButton = wait3.until(ExpectedConditions.visibilityOfElementLocated(op.submitButtonID));

	           // WebElement submitButton = (WebElement) driver.findElementByAccessibilityId(submitButtonID);
	            submitButton.click();
	            
	           
	            
	            System.out.println("Login UnSuccessfull");
	            
	            Thread.sleep(3000);

	        } catch (Exception e) {
	            System.out.println("*** Problem to login: " + e.getMessage());
	        }
	    }

	    
	    public void validateOTP() throws Throwable {
	        
	    	WebDriverWait wait = new WebDriverWait(driver, 90);
	    	Thread.sleep(30000);
	        WebElement enterOTP = wait.until(ExpectedConditions.visibilityOfElementLocated(op.signInAccesscode));
	        enterOTP.click();
	        System.out.println("Enter access code...");
	        Thread.sleep(30000);
	        
	        enterOTP.sendKeys("");
	        System.out.println("OTP entered Successfully");
	        
	        WebElement Checkbox = wait.until(ExpectedConditions.visibilityOfElementLocated(op.skipCheckbox));
	        Checkbox.click();
	        System.out.println("Skip checkbox selected");
	        
	        WebElement clkNextbutton = wait.until(ExpectedConditions.visibilityOfElementLocated(op.clickNextbutton));
	        clkNextbutton.click();
	        System.out.println("Next button clicked");
	   }
	    
	    public void homeMenuItems() {
	    	 WebDriverWait wait = new WebDriverWait(driver, 60);
	          WebElement optumHeader = wait.until(ExpectedConditions.visibilityOfElementLocated(op.optumHeaderTitle));
	          
	         assertTrue(optumHeader.isDisplayed());
	            
	    }
	    
	    public void scheduleScreen()throws Throwable{
	    	
	    	WebDriverWait wait = new WebDriverWait(driver, 90);
	    	Thread.sleep(30000);
	        WebElement clkSchedule = wait.until(ExpectedConditions.visibilityOfElementLocated(op.clickOnSchedule));
	        clkSchedule.click();
	        
	        WebDriverWait wait2 = new WebDriverWait(driver, 90);
	    	Thread.sleep(30000);
	        WebElement verScheduleHeader = wait2.until(ExpectedConditions.visibilityOfElementLocated(op.verifyScheduleHeader));
	        verScheduleHeader.click();
	        
	        WebDriverWait wait3 = new WebDriverWait(driver, 90);
	    	Thread.sleep(30000);
	        WebElement clkOnLeftArrow = wait3.until(ExpectedConditions.visibilityOfElementLocated(op.clickOnleftArrow));
	        clkOnLeftArrow.click();
	        
	        WebDriverWait wait4 = new WebDriverWait(driver, 90);
	    	Thread.sleep(30000);
	        WebElement valappointmentHeader = wait4.until(ExpectedConditions.visibilityOfElementLocated(op.appointmentsHeader));
	        valappointmentHeader.click();
	        
	        WebDriverWait wait5 = new WebDriverWait(driver, 90);
	    	Thread.sleep(30000);
	        WebElement verName = wait5.until(ExpectedConditions.visibilityOfElementLocated(op.verifyName));
	        verName.click();
	        
	        WebDriverWait wait6 = new WebDriverWait(driver, 90);
	    	Thread.sleep(30000);
	        WebElement clkSchDots = wait6.until(ExpectedConditions.visibilityOfElementLocated(op.clickondots));
	        clkSchDots.click();
	        
	        WebDriverWait wait7 = new WebDriverWait(driver, 90);
	    	Thread.sleep(30000);
	        WebElement verAutoCal = wait7.until(ExpectedConditions.visibilityOfElementLocated(op.verifyAutoCall));
	        verAutoCal.click();
	        
	        WebDriverWait wait8 = new WebDriverWait(driver, 90);
	    	Thread.sleep(30000);
	        WebElement verMapRoute = wait8.until(ExpectedConditions.visibilityOfElementLocated(op.verifyMapRoute));
	        verMapRoute.click();
	        
	        WebDriverWait wait9 = new WebDriverWait(driver, 90);
	    	Thread.sleep(30000);
	        WebElement verCallTeamCare = wait9.until(ExpectedConditions.visibilityOfElementLocated(op.verifyCallTeamCare));
	        verCallTeamCare.click();
	        
	        WebDriverWait wait10 = new WebDriverWait(driver, 90);
	    	Thread.sleep(30000);
	        WebElement verAddNewTask = wait10.until(ExpectedConditions.visibilityOfElementLocated(op.AddNewTask));
	        verAddNewTask.click();
	        
	        WebDriverWait wait11 = new WebDriverWait(driver, 90);
	    	Thread.sleep(30000);
	        WebElement clkbackToMenu = wait11.until(ExpectedConditions.visibilityOfElementLocated(op.clickbackToMenu));
	        clkbackToMenu.click();
	        
	        
	    }
	    
	    public void addTasks()throws Throwable{
	    	WebDriverWait wait11 = new WebDriverWait(driver, 90);
	    	Thread.sleep(30000);
	        WebElement clkbackToMenu = wait11.until(ExpectedConditions.visibilityOfElementLocated(op.clickbackToMenu));
	        
	    }


}
