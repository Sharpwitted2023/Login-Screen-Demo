package tests;

import org.testng.annotations.Test;

import pages.ReusableComponent;

public class OptumAndroidTests extends BaseClass{
	
	ReusableComponent rc=new ReusableComponent();
	
	String user_id="shirema5";
	String pass_word="Sharp@901";
	String invalid_passWord="Sharp123";
	
	@Test
	public void login(String userName, String passWord,String invalid_pwd) {
		rc.appLogo();
		rc.validateTitle();
		userName=user_id;
		passWord=pass_word;
		invalid_pwd=invalid_passWord;
		rc.invalidlogin(userName,invalid_pwd);
		rc.login(userName,passWord);
	}
	
	@Test
	public void enterOTP() {
		System.out.println("Skipping for time being");
	}
	
	@Test
	public void validateHomeScreenMenu() {
		
	}
	
	@Test
	public void validateLeftNavigationMenu() {
		
	}
	
	@Test
	public void validateScheduleScreenforFutureDate() {
		
	}
	
	@Test
	public void validateAppointMentsforFutureDate() {
		
	}
	
	@Test
	public void validateTasksScreen() {
		
	}
	
	@Test
	public void validateScheduleDetailScreen() {
		
	}
	
	@Test
	public void validateReScheduleScreen() {
		
	}
	
	@Test
	public void validateReScheduledAppointmentScreen() {
		
	}
	
	@Test
	public void validateNotificationsScreen() {
		
	}
	
}
